export default function Marketplace(){
return(
<div style={{padding:40}}>
<h2>Marketplace</h2>
<p>Hire Roblox developers, post jobs, apply instantly</p>
</div>
)
}
