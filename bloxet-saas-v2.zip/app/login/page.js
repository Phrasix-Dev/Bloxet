"use client";
import { useState } from "react";

export default function Login(){
const [name,setName]=useState("");

const login=()=>{
document.cookie = "bloxet_session="+name;
window.location.href="/dashboard";
};

return(
<div style={{padding:40}}>
<h2>Login with Roblox Username</h2>
<input value={name} onChange={e=>setName(e.target.value)} />
<button onClick={login}>Login</button>
</div>
)
}
