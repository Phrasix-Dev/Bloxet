export default function Dashboard(){
return(
<div style={{padding:40}}>
<h1>Dashboard</h1>
<p>Welcome to Bloxet SaaS Control Center</p>
</div>
)
}
