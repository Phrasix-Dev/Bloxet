export default function Home(){
return(
<div style={{padding:50}}>
<h1 style={{color:'#8b5cf6'}}>Bloxet SaaS</h1>
<p>Roblox Dev Marketplace + Discord SaaS Platform</p>
<a href="/login">Get Started</a>
</div>
)
}
