"use client";
import { useState } from "react";

export default function Chat(){
const [messages,setMessages]=useState([]);
const [text,setText]=useState("");

const send=()=>{
setMessages([...messages,{text}]);
setText("");
};

return(
<div style={{padding:30}}>
<h2>Live Chat (SaaS mode)</h2>
{messages.map((m,i)=><p key={i}>{m.text}</p>)}
<input value={text} onChange={e=>setText(e.target.value)} />
<button onClick={send}>Send</button>
</div>
)
}
